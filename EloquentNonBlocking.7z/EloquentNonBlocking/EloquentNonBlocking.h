#define every(interval) \
  static uint32_t __every__##interval = millis(); \
  if (millis() - __every__##interval >= interval && (__every__##interval = millis()))

// these are for greater code readability
#define Millis
#define Second  *1000
#define Seconds *1000